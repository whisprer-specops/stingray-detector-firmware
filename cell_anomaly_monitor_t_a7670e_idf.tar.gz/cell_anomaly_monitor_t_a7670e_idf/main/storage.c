#include "storage.h"

#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "config.h"
#include "driver/sdspi_host.h"
#include "driver/spi_common.h"
#include "esp_check.h"
#include "esp_log.h"
#include "esp_vfs_fat.h"
#include "sdmmc_cmd.h"

static const char *TAG = APP_TAG ".storage";
static sdmmc_card_t *s_card;
static bool s_bus_initialized;

static esp_err_t ensure_dir(const char *path)
{
    struct stat st;
    if (stat(path, &st) == 0) {
        if (S_ISDIR(st.st_mode)) {
            return ESP_OK;
        }
        return ESP_FAIL;
    }
    if (mkdir(path, 0775) == 0) {
        return ESP_OK;
    }
    if (errno == EEXIST) {
        return ESP_OK;
    }
    return ESP_FAIL;
}

static void append_json_escaped(FILE *f, const char *text)
{
    if (text == NULL) {
        return;
    }
    for (const unsigned char *p = (const unsigned char *)text; *p != '\0'; ++p) {
        switch (*p) {
            case '\\': fputs("\\\\", f); break;
            case '"':  fputs("\\\"", f); break;
            case '\n': fputs("\\n", f); break;
            case '\r': fputs("\\r", f); break;
            case '\t': fputs("\\t", f); break;
            default:
                if (*p < 0x20) {
                    fprintf(f, "\\u%04x", *p);
                } else {
                    fputc(*p, f);
                }
                break;
        }
    }
}

static esp_err_t write_csv_header_if_needed(FILE *f)
{
    long pos = ftell(f);
    if (pos != 0) {
        return ESP_OK;
    }
    fprintf(f,
            "uptime_ms,sim_ready,registered,rat,op_mode,plmn,tac,cell_id,pcell_id,band,earfcn,dlbw,ulbw,"
            "rsrp_dbm,rsrq_db,rssi_dbm,rssnr_raw,csq_rssi_code,csq_ber,creg_mode,creg_stat,cereg_mode,cereg_stat,"
            "score,level,baseline_hits,new_cell,changed_cell,rat_downgrade,registration_flap,flags\n");
    return ESP_OK;
}

esp_err_t storage_init(storage_context_t *ctx)
{
    if (ctx == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    memset(ctx, 0, sizeof(*ctx));

    sdmmc_host_t host = SDSPI_HOST_DEFAULT();
    host.slot = SPI2_HOST;

    if (!s_bus_initialized) {
        spi_bus_config_t bus_cfg = {
            .mosi_io_num = BOARD_GPIO_SD_MOSI,
            .miso_io_num = BOARD_GPIO_SD_MISO,
            .sclk_io_num = BOARD_GPIO_SD_SCK,
            .quadwp_io_num = -1,
            .quadhd_io_num = -1,
            .max_transfer_sz = 16 * 1024,
        };
        ESP_RETURN_ON_ERROR(spi_bus_initialize(host.slot, &bus_cfg, SDSPI_DEFAULT_DMA), TAG, "init spi bus");
        s_bus_initialized = true;
    }

    sdspi_device_config_t slot_cfg = SDSPI_DEVICE_CONFIG_DEFAULT();
    slot_cfg.gpio_cs = BOARD_GPIO_SD_CS;
    slot_cfg.host_id = host.slot;

    esp_vfs_fat_sdmmc_mount_config_t mount_cfg = {
        .format_if_mount_failed = false,
        .max_files = STORAGE_MAX_FILES,
        .allocation_unit_size = STORAGE_ALLOCATION_UNIT,
    };

    esp_err_t err = esp_vfs_fat_sdspi_mount(STORAGE_MOUNT_POINT, &host, &slot_cfg, &mount_cfg, &s_card);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "sd mount failed: %s", esp_err_to_name(err));
        return err;
    }

    ESP_RETURN_ON_ERROR(ensure_dir(STORAGE_LOG_DIR), TAG, "create log dir");
    ctx->mounted = true;
    ESP_LOGI(TAG, "mounted sd card at %s", STORAGE_MOUNT_POINT);
    return ESP_OK;
}

void storage_deinit(storage_context_t *ctx)
{
    if (ctx == NULL || !ctx->mounted) {
        return;
    }
    esp_vfs_fat_sdcard_unmount(STORAGE_MOUNT_POINT, s_card);
    s_card = NULL;
    ctx->mounted = false;
}

esp_err_t storage_append_snapshot(storage_context_t *ctx,
                                  const cell_snapshot_t *snapshot,
                                  const detector_result_t *result)
{
    if (ctx == NULL || snapshot == NULL || result == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    if (!ctx->mounted) {
        return ESP_ERR_INVALID_STATE;
    }

    FILE *csv = fopen(STORAGE_CSV_PATH, "a+");
    if (csv == NULL) {
        ESP_LOGE(TAG, "failed to open csv log: errno=%d", errno);
        return ESP_FAIL;
    }

    write_csv_header_if_needed(csv);
    fprintf(csv,
            "%lld,%d,%d,%s,%s,%s,%u,%u,%d,%s,%d,%d,%d,%d,%.1f,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,\"%s\"\n",
            (long long)snapshot->uptime_ms,
            snapshot->sim_ready,
            snapshot->registered,
            snapshot->rat_text,
            snapshot->op_mode,
            snapshot->plmn,
            snapshot->tac,
            snapshot->cell_id,
            snapshot->pcell_id,
            snapshot->band,
            snapshot->earfcn,
            snapshot->dlbw,
            snapshot->ulbw,
            snapshot->rsrp_dbm,
            snapshot->rsrq_db,
            snapshot->rssi_dbm,
            snapshot->rssnr_raw,
            snapshot->csq_rssi_code,
            snapshot->csq_ber,
            snapshot->creg_mode,
            snapshot->creg_stat,
            snapshot->cereg_mode,
            snapshot->cereg_stat,
            result->score,
            (int)result->level,
            result->baseline_hits,
            result->new_cell,
            result->changed_cell,
            result->rat_downgrade,
            result->registration_flap,
            result->flags);
    fclose(csv);
    ctx->log_count += 1;

    if (result->level >= EVENT_LOW) {
        FILE *events = fopen(STORAGE_EVENT_PATH, "a");
        if (events == NULL) {
            ESP_LOGE(TAG, "failed to open event log: errno=%d", errno);
            return ESP_FAIL;
        }
        fputs("{\"uptime_ms\":", events);
        fprintf(events, "%lld", (long long)snapshot->uptime_ms);
        fputs(",\"score\":", events);
        fprintf(events, "%d", result->score);
        fputs(",\"level\":", events);
        fprintf(events, "%d", (int)result->level);
        fputs(",\"rat\":\"", events);
        append_json_escaped(events, snapshot->rat_text);
        fputs("\",\"plmn\":\"", events);
        append_json_escaped(events, snapshot->plmn);
        fputs("\",\"tac\":", events);
        fprintf(events, "%u", snapshot->tac);
        fputs(",\"cell_id\":", events);
        fprintf(events, "%u", snapshot->cell_id);
        fputs(",\"band\":\"", events);
        append_json_escaped(events, snapshot->band);
        fputs("\",\"flags\":\"", events);
        append_json_escaped(events, result->flags);
        fputs("\"}\n", events);
        fclose(events);
        ctx->event_count += 1;
    }

    return ESP_OK;
}
