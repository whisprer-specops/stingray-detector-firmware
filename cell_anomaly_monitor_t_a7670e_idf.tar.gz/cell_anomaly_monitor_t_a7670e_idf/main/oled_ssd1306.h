#include <stdbool.h>
#pragma once

#include "esp_err.h"

typedef struct oled_context {
    bool ready;
} oled_context_t;

esp_err_t oled_init(oled_context_t *ctx);
void oled_clear(void);
void oled_draw_text(int col, int row, const char *text);
esp_err_t oled_present(void);
