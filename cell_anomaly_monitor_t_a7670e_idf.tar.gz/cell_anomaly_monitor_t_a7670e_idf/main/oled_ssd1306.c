#include "oled_ssd1306.h"

#include <string.h>

#include "config.h"
#include "driver/i2c.h"
#include "esp_check.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "oled_font_6x8.h"

static const char *TAG = APP_TAG ".oled";
static bool s_ready;
static uint8_t s_buffer[OLED_WIDTH * OLED_HEIGHT / 8];

static esp_err_t oled_write_command(uint8_t command)
{
    i2c_cmd_handle_t handle = i2c_cmd_link_create();
    i2c_master_start(handle);
    i2c_master_write_byte(handle, (OLED_ADDR << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(handle, 0x00, true);
    i2c_master_write_byte(handle, command, true);
    i2c_master_stop(handle);
    esp_err_t err = i2c_master_cmd_begin(OLED_I2C_PORT, handle, pdMS_TO_TICKS(100));
    i2c_cmd_link_delete(handle);
    return err;
}

static esp_err_t oled_write_data(const uint8_t *data, size_t len)
{
    i2c_cmd_handle_t handle = i2c_cmd_link_create();
    i2c_master_start(handle);
    i2c_master_write_byte(handle, (OLED_ADDR << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(handle, 0x40, true);
    i2c_master_write(handle, (uint8_t *)data, len, true);
    i2c_master_stop(handle);
    esp_err_t err = i2c_master_cmd_begin(OLED_I2C_PORT, handle, pdMS_TO_TICKS(100));
    i2c_cmd_link_delete(handle);
    return err;
}

esp_err_t oled_init(oled_context_t *ctx)
{
    const uint8_t init_cmds[] = {
        0xAE, 0x20, 0x00, 0xB0, 0xC8, 0x00, 0x10, 0x40,
        0x81, 0x7F, 0xA1, 0xA6, 0xA8, 0x3F, 0xA4, 0xD3,
        0x00, 0xD5, 0x80, 0xD9, 0xF1, 0xDA, 0x12, 0xDB,
        0x20, 0x8D, 0x14, 0xAF,
    };

    for (size_t i = 0; i < sizeof(init_cmds); ++i) {
        ESP_RETURN_ON_ERROR(oled_write_command(init_cmds[i]), TAG, "send init cmd");
    }

    s_ready = true;
    oled_clear();
    ESP_RETURN_ON_ERROR(oled_present(), TAG, "present clear buffer");

    if (ctx != NULL) {
        ctx->ready = true;
    }
    return ESP_OK;
}

void oled_clear(void)
{
    if (!s_ready) {
        return;
    }
    memset(s_buffer, 0, sizeof(s_buffer));
}

static void oled_put_glyph(int x, int page, char ch)
{
    if (x < 0 || x + OLED_CHAR_WIDTH > OLED_WIDTH || page < 0 || page >= (OLED_HEIGHT / 8)) {
        return;
    }

    int index = (int)ch - 32;
    if (index < 0 || index >= 95) {
        index = '?' - 32;
    }

    const size_t offset = (size_t)page * OLED_WIDTH + (size_t)x;
    memcpy(&s_buffer[offset], oled_font_6x8[index], OLED_CHAR_WIDTH);
}

void oled_draw_text(int col, int row, const char *text)
{
    if (!s_ready || text == NULL) {
        return;
    }

    int x = col * OLED_CHAR_WIDTH;
    int page = row;
    for (const char *p = text; *p != '\0'; ++p) {
        if (x + OLED_CHAR_WIDTH > OLED_WIDTH) {
            break;
        }
        oled_put_glyph(x, page, *p);
        x += OLED_CHAR_WIDTH;
    }
}

esp_err_t oled_present(void)
{
    if (!s_ready) {
        return ESP_ERR_INVALID_STATE;
    }
    for (int page = 0; page < (OLED_HEIGHT / 8); ++page) {
        ESP_RETURN_ON_ERROR(oled_write_command((uint8_t)(0xB0 + page)), TAG, "set page");
        ESP_RETURN_ON_ERROR(oled_write_command(0x00), TAG, "set low column");
        ESP_RETURN_ON_ERROR(oled_write_command(0x10), TAG, "set high column");
        ESP_RETURN_ON_ERROR(oled_write_data(&s_buffer[page * OLED_WIDTH], OLED_WIDTH), TAG, "write page");
    }
    return ESP_OK;
}
