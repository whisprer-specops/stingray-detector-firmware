#pragma once

#include "esp_err.h"

esp_err_t board_init_power_domain(void);
esp_err_t board_init_i2c(void);
esp_err_t board_init_uart(void);
esp_err_t board_prepare_modem_pins(void);
void board_modem_reset_pulse(void);
void board_modem_power_key_pulse(void);
void board_modem_hold_awake(void);
