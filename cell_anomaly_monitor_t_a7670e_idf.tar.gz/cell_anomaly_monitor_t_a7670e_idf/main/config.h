#pragma once

#include <stdbool.h>
#include <stdint.h>
#include "driver/gpio.h"
#include "driver/i2c.h"
#include "driver/uart.h"

#define APP_TAG "cellmon"

#define BOARD_VARIANT_NAME "LilyGo T-A7670E/T-A7670G ESP32"

/* LilyGo T-A7670X ESP32 pin map from the vendor quick-start docs. */
#define BOARD_GPIO_PERIPHERAL_POWER GPIO_NUM_12
#define BOARD_GPIO_MODEM_TX         GPIO_NUM_26
#define BOARD_GPIO_MODEM_RX         GPIO_NUM_27
#define BOARD_GPIO_MODEM_PWRKEY     GPIO_NUM_4
#define BOARD_GPIO_MODEM_RESET      GPIO_NUM_5
#define BOARD_GPIO_MODEM_RING       GPIO_NUM_33
#define BOARD_GPIO_MODEM_DTR        GPIO_NUM_25

#define BOARD_GPIO_SD_SCK           GPIO_NUM_14
#define BOARD_GPIO_SD_MISO          GPIO_NUM_2
#define BOARD_GPIO_SD_MOSI          GPIO_NUM_15
#define BOARD_GPIO_SD_CS            GPIO_NUM_13

/* Default I2C pins for T-A7670X ESP32. If you have the A7670G external-GPS
 * version, move these to free GPIOs because 21/22 may already be used by GNSS. */
#ifndef BOARD_GPIO_OLED_SDA
#define BOARD_GPIO_OLED_SDA         GPIO_NUM_21
#endif
#ifndef BOARD_GPIO_OLED_SCL
#define BOARD_GPIO_OLED_SCL         GPIO_NUM_22
#endif

#define MODEM_UART_PORT             UART_NUM_1
#define MODEM_UART_BAUD             115200
#define MODEM_UART_RX_BUFFER        4096
#define MODEM_UART_TX_BUFFER        1024

#define MODEM_RESET_LEVEL           1
#define MODEM_POWERON_PULSE_MS      100
#define MODEM_START_WAIT_MS         3000
#define MODEM_COMMAND_TIMEOUT_MS    4000
#define MODEM_BOOT_RETRIES          3

#define MONITOR_POLL_INTERVAL_MS    5000
#define MONITOR_REDRAW_INTERVAL_MS  1000
#define MONITOR_MAX_AT_RESPONSE     768

#define OLED_I2C_PORT               I2C_NUM_0
#define OLED_I2C_FREQ_HZ            400000
#define OLED_ADDR                   0x3C
#define OLED_WIDTH                  128
#define OLED_HEIGHT                 64
#define OLED_CHAR_WIDTH             6
#define OLED_CHAR_HEIGHT            8
#define OLED_TEXT_COLS              (OLED_WIDTH / OLED_CHAR_WIDTH)
#define OLED_TEXT_ROWS              (OLED_HEIGHT / OLED_CHAR_HEIGHT)

#define STORAGE_MOUNT_POINT         "/sdcard"
#define STORAGE_LOG_DIR             "/sdcard/cellmon"
#define STORAGE_CSV_PATH            "/sdcard/cellmon/cell_log.csv"
#define STORAGE_EVENT_PATH          "/sdcard/cellmon/anomaly_events.jsonl"
#define STORAGE_MAX_FILES           4
#define STORAGE_ALLOCATION_UNIT     (16 * 1024)

#define BASELINE_CAPACITY           128
#define FLAG_TEXT_LEN               256
#define MODEM_TEXT_LEN              32
#define MODEM_BAND_LEN              32
#define MODEM_RAW_LINE_LEN          192

#define DETECTOR_NEW_STRONG_SCORE          20
#define DETECTOR_CELL_CHURN_SCORE          12
#define DETECTOR_REG_FLAP_SCORE            18
#define DETECTOR_RAT_DOWNGRADE_SCORE       28
#define DETECTOR_SIGNAL_JUMP_SCORE          8
#define DETECTOR_PLMN_SWITCH_SCORE         15
#define DETECTOR_NO_SERVICE_AFTER_GOOD      8

#define DETECTOR_ALERT_LOW                 25
#define DETECTOR_ALERT_MEDIUM              40
#define DETECTOR_ALERT_HIGH                60

#define DETECTOR_STRONG_RSRP_DBM          (-85)
#define DETECTOR_STRONG_RSSI_DBM          (-65)
#define DETECTOR_SIGNAL_JUMP_DB            18
#define DETECTOR_CHURN_WINDOW_MS      (90 * 1000)
#define DETECTOR_FLAP_WINDOW_MS       (30 * 1000)

typedef enum rat_mode {
    RAT_UNKNOWN = 0,
    RAT_NO_SERVICE,
    RAT_GSM,
    RAT_WCDMA,
    RAT_LTE,
} rat_mode_t;

typedef enum event_level {
    EVENT_NONE = 0,
    EVENT_LOW,
    EVENT_MEDIUM,
    EVENT_HIGH,
} event_level_t;

typedef struct cell_snapshot {
    bool valid;
    bool sim_ready;
    bool registered;
    bool no_service;
    int64_t uptime_ms;

    int creg_mode;
    int creg_stat;
    int cereg_mode;
    int cereg_stat;
    int csq_rssi_code;
    int csq_ber;

    rat_mode_t rat;
    char rat_text[MODEM_TEXT_LEN];
    char op_mode[MODEM_TEXT_LEN];
    char plmn[MODEM_TEXT_LEN];
    char band[MODEM_BAND_LEN];

    uint32_t tac;
    uint32_t cell_id;
    int pcell_id;
    int earfcn;
    int dlbw;
    int ulbw;
    int rsrp_dbm;
    float rsrq_db;
    int rssi_dbm;
    int rssnr_raw;

    char modem_model[MODEM_TEXT_LEN];
    char modem_revision[MODEM_TEXT_LEN];
    char cpsi_line[MODEM_RAW_LINE_LEN];
} cell_snapshot_t;

typedef struct detector_result {
    int score;
    event_level_t level;
    int baseline_hits;
    bool changed_cell;
    bool new_cell;
    bool rat_downgrade;
    bool registration_flap;
    bool sd_logging_ok;
    char flags[FLAG_TEXT_LEN];
} detector_result_t;

typedef struct display_state {
    bool storage_ready;
    bool modem_ready;
    int sample_count;
    int event_count;
    int last_score;
    event_level_t last_level;
    cell_snapshot_t last_snapshot;
    detector_result_t last_detector;
    char status_line[MODEM_RAW_LINE_LEN];
} display_state_t;
