#include "board.h"

#include "config.h"

#include "driver/gpio.h"
#include "driver/i2c.h"
#include "driver/uart.h"
#include "esp_check.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = APP_TAG ".board";

esp_err_t board_init_power_domain(void)
{
    ESP_RETURN_ON_ERROR(gpio_reset_pin(BOARD_GPIO_PERIPHERAL_POWER), TAG, "reset peripheral power pin");
    ESP_RETURN_ON_ERROR(gpio_set_direction(BOARD_GPIO_PERIPHERAL_POWER, GPIO_MODE_OUTPUT), TAG, "set peripheral power pin");
    ESP_RETURN_ON_ERROR(gpio_set_level(BOARD_GPIO_PERIPHERAL_POWER, 1), TAG, "enable peripheral power rail");
    vTaskDelay(pdMS_TO_TICKS(50));
    return ESP_OK;
}

esp_err_t board_init_i2c(void)
{
    const i2c_config_t cfg = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = BOARD_GPIO_OLED_SDA,
        .scl_io_num = BOARD_GPIO_OLED_SCL,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = OLED_I2C_FREQ_HZ,
        .clk_flags = 0,
    };

    ESP_RETURN_ON_ERROR(i2c_param_config(OLED_I2C_PORT, &cfg), TAG, "configure i2c");
    ESP_RETURN_ON_ERROR(i2c_driver_install(OLED_I2C_PORT, cfg.mode, 0, 0, 0), TAG, "install i2c");
    return ESP_OK;
}

esp_err_t board_init_uart(void)
{
    const uart_config_t cfg = {
        .baud_rate = MODEM_UART_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };

    ESP_RETURN_ON_ERROR(uart_driver_install(MODEM_UART_PORT, MODEM_UART_RX_BUFFER, MODEM_UART_TX_BUFFER, 0, NULL, 0), TAG, "install uart");
    ESP_RETURN_ON_ERROR(uart_param_config(MODEM_UART_PORT, &cfg), TAG, "config uart");
    ESP_RETURN_ON_ERROR(uart_set_pin(MODEM_UART_PORT, BOARD_GPIO_MODEM_TX, BOARD_GPIO_MODEM_RX, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE), TAG, "set uart pins");
    ESP_RETURN_ON_ERROR(uart_flush(MODEM_UART_PORT), TAG, "flush uart");
    return ESP_OK;
}

esp_err_t board_prepare_modem_pins(void)
{
    const gpio_num_t outputs[] = {
        BOARD_GPIO_MODEM_PWRKEY,
        BOARD_GPIO_MODEM_RESET,
        BOARD_GPIO_MODEM_DTR,
    };

    for (size_t i = 0; i < sizeof(outputs) / sizeof(outputs[0]); ++i) {
        ESP_RETURN_ON_ERROR(gpio_reset_pin(outputs[i]), TAG, "reset modem gpio");
        ESP_RETURN_ON_ERROR(gpio_set_direction(outputs[i], GPIO_MODE_OUTPUT), TAG, "set modem gpio direction");
    }

    ESP_RETURN_ON_ERROR(gpio_reset_pin(BOARD_GPIO_MODEM_RING), TAG, "reset ring pin");
    ESP_RETURN_ON_ERROR(gpio_set_direction(BOARD_GPIO_MODEM_RING, GPIO_MODE_INPUT), TAG, "set ring input");

    ESP_RETURN_ON_ERROR(gpio_set_level(BOARD_GPIO_MODEM_PWRKEY, 0), TAG, "idle pwrkey");
    ESP_RETURN_ON_ERROR(gpio_set_level(BOARD_GPIO_MODEM_RESET, !MODEM_RESET_LEVEL), TAG, "idle reset");
    ESP_RETURN_ON_ERROR(gpio_set_level(BOARD_GPIO_MODEM_DTR, 0), TAG, "hold modem awake");

    return ESP_OK;
}

void board_modem_hold_awake(void)
{
    gpio_set_level(BOARD_GPIO_MODEM_DTR, 0);
}

void board_modem_reset_pulse(void)
{
    ESP_LOGI(TAG, "hard reset modem");
    gpio_set_level(BOARD_GPIO_MODEM_RESET, !MODEM_RESET_LEVEL);
    vTaskDelay(pdMS_TO_TICKS(100));
    gpio_set_level(BOARD_GPIO_MODEM_RESET, MODEM_RESET_LEVEL);
    vTaskDelay(pdMS_TO_TICKS(2600));
    gpio_set_level(BOARD_GPIO_MODEM_RESET, !MODEM_RESET_LEVEL);
    vTaskDelay(pdMS_TO_TICKS(100));
}

void board_modem_power_key_pulse(void)
{
    ESP_LOGI(TAG, "pulse modem pwrkey");
    gpio_set_level(BOARD_GPIO_MODEM_PWRKEY, 0);
    vTaskDelay(pdMS_TO_TICKS(100));
    gpio_set_level(BOARD_GPIO_MODEM_PWRKEY, 1);
    vTaskDelay(pdMS_TO_TICKS(MODEM_POWERON_PULSE_MS));
    gpio_set_level(BOARD_GPIO_MODEM_PWRKEY, 0);
}
