#include "detector.h"

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

static void append_flag(char *dst, size_t dst_size, const char *fmt, ...)
{
    if (dst == NULL || dst_size == 0 || fmt == NULL) {
        return;
    }

    size_t used = strlen(dst);
    if (used >= dst_size - 1U) {
        return;
    }

    if (used > 0) {
        int sep = snprintf(dst + used, dst_size - used, "; ");
        if (sep < 0) {
            return;
        }
        used += (size_t)sep;
        if (used >= dst_size - 1U) {
            return;
        }
    }

    va_list args;
    va_start(args, fmt);
    vsnprintf(dst + used, dst_size - used, fmt, args);
    va_end(args);
}

static bool same_cell(const cell_snapshot_t *a, const cell_snapshot_t *b)
{
    return a->rat == b->rat &&
           a->tac == b->tac &&
           a->cell_id == b->cell_id &&
           strncmp(a->plmn, b->plmn, sizeof(a->plmn)) == 0;
}

static baseline_entry_t *find_baseline(detector_state_t *state, const cell_snapshot_t *snapshot)
{
    baseline_entry_t *free_slot = NULL;
    for (size_t i = 0; i < BASELINE_CAPACITY; ++i) {
        baseline_entry_t *entry = &state->entries[i];
        if (!entry->used) {
            if (free_slot == NULL) {
                free_slot = entry;
            }
            continue;
        }
        if (entry->rat == snapshot->rat &&
            entry->tac == snapshot->tac &&
            entry->cell_id == snapshot->cell_id &&
            strncmp(entry->plmn, snapshot->plmn, sizeof(entry->plmn)) == 0) {
            return entry;
        }
    }
    return free_slot;
}

static void update_baseline_entry(baseline_entry_t *entry, const cell_snapshot_t *snapshot)
{
    if (!entry->used) {
        memset(entry, 0, sizeof(*entry));
        entry->used = true;
        entry->rat = snapshot->rat;
        snprintf(entry->plmn, sizeof(entry->plmn), "%s", snapshot->plmn);
        entry->tac = snapshot->tac;
        entry->cell_id = snapshot->cell_id;
        entry->first_seen_ms = snapshot->uptime_ms;
        entry->avg_rsrp_dbm = snapshot->rsrp_dbm;
        entry->avg_rssi_dbm = snapshot->rssi_dbm;
    }

    entry->seen_count += 1;
    entry->last_seen_ms = snapshot->uptime_ms;
    if (snapshot->rsrp_dbm != 0) {
        entry->avg_rsrp_dbm = (entry->avg_rsrp_dbm == 0)
                                  ? snapshot->rsrp_dbm
                                  : ((entry->avg_rsrp_dbm * (entry->seen_count - 1)) + snapshot->rsrp_dbm) / entry->seen_count;
    }
    if (snapshot->rssi_dbm != 0) {
        entry->avg_rssi_dbm = (entry->avg_rssi_dbm == 0)
                                  ? snapshot->rssi_dbm
                                  : ((entry->avg_rssi_dbm * (entry->seen_count - 1)) + snapshot->rssi_dbm) / entry->seen_count;
    }
}

void detector_init(detector_state_t *state)
{
    memset(state, 0, sizeof(*state));
}

void detector_update(detector_state_t *state,
                     const cell_snapshot_t *snapshot,
                     detector_result_t *result)
{
    memset(result, 0, sizeof(*result));
    result->level = EVENT_NONE;

    if (!snapshot->valid) {
        snprintf(result->flags, sizeof(result->flags), "SIM not ready / no valid snapshot");
        return;
    }

    state->sample_count += 1;
    baseline_entry_t *entry = find_baseline(state, snapshot);
    const bool entry_was_used = (entry != NULL && entry->used);
    if (entry != NULL) {
        result->baseline_hits = entry->seen_count;
    }

    if (state->has_previous) {
        result->changed_cell = !same_cell(&state->previous, snapshot);
        if (result->changed_cell &&
            (snapshot->uptime_ms - state->previous.uptime_ms) <= DETECTOR_CHURN_WINDOW_MS) {
            result->score += DETECTOR_CELL_CHURN_SCORE;
            append_flag(result->flags, sizeof(result->flags), "fast cell change");
        }

        if (state->previous.registered != snapshot->registered) {
            if ((snapshot->uptime_ms - state->last_reg_change_ms) <= DETECTOR_FLAP_WINDOW_MS) {
                state->reg_flap_count += 1;
            } else {
                state->reg_flap_count = 1;
            }
            state->last_reg_change_ms = snapshot->uptime_ms;
        }

        if (state->reg_flap_count >= 2) {
            result->registration_flap = true;
            result->score += DETECTOR_REG_FLAP_SCORE;
            append_flag(result->flags, sizeof(result->flags), "registration flapping");
        }

        if (state->previous.rat == RAT_LTE && snapshot->rat == RAT_GSM) {
            result->rat_downgrade = true;
            result->score += DETECTOR_RAT_DOWNGRADE_SCORE;
            append_flag(result->flags, sizeof(result->flags), "LTE to GSM downgrade");
        }

        int previous_strength = state->previous.rsrp_dbm != 0 ? state->previous.rsrp_dbm : state->previous.rssi_dbm;
        int current_strength = snapshot->rsrp_dbm != 0 ? snapshot->rsrp_dbm : snapshot->rssi_dbm;
        if (previous_strength != 0 && current_strength != 0) {
            const int jump = current_strength - previous_strength;
            if (jump >= DETECTOR_SIGNAL_JUMP_DB) {
                result->score += DETECTOR_SIGNAL_JUMP_SCORE;
                append_flag(result->flags, sizeof(result->flags), "signal jump +%ddB", jump);
            }
        }

        if (state->previous.registered && snapshot->no_service) {
            result->score += DETECTOR_NO_SERVICE_AFTER_GOOD;
            append_flag(result->flags, sizeof(result->flags), "lost service after registration");
        }

        if (state->previous.plmn[0] != '\0' && snapshot->plmn[0] != '\0' &&
            strcmp(state->previous.plmn, snapshot->plmn) != 0) {
            result->score += DETECTOR_PLMN_SWITCH_SCORE;
            append_flag(result->flags, sizeof(result->flags), "PLMN changed %s->%s", state->previous.plmn, snapshot->plmn);
        }
    }

    if (!entry_was_used) {
        result->new_cell = true;
        const bool strong_rsrp = (snapshot->rsrp_dbm != 0 && snapshot->rsrp_dbm >= DETECTOR_STRONG_RSRP_DBM);
        const bool strong_rssi = (snapshot->rssi_dbm != 0 && snapshot->rssi_dbm >= DETECTOR_STRONG_RSSI_DBM);
        if (strong_rsrp || strong_rssi) {
            result->score += DETECTOR_NEW_STRONG_SCORE;
            append_flag(result->flags, sizeof(result->flags), "new strong cell");
        } else {
            append_flag(result->flags, sizeof(result->flags), "new cell");
        }
    }

    if (result->score >= DETECTOR_ALERT_HIGH) {
        result->level = EVENT_HIGH;
    } else if (result->score >= DETECTOR_ALERT_MEDIUM) {
        result->level = EVENT_MEDIUM;
    } else if (result->score >= DETECTOR_ALERT_LOW) {
        result->level = EVENT_LOW;
    }

    if (entry != NULL) {
        update_baseline_entry(entry, snapshot);
        result->baseline_hits = entry->seen_count;
    }

    state->previous = *snapshot;
    state->has_previous = true;
}
