#pragma once

#include "esp_err.h"
#include "config.h"

typedef struct modem_context {
    bool ready;
    int boot_attempts;
    char last_response[MONITOR_MAX_AT_RESPONSE];
    char model[MODEM_TEXT_LEN];
    char revision[MODEM_TEXT_LEN];
} modem_context_t;

esp_err_t modem_init(modem_context_t *ctx);
esp_err_t modem_collect_snapshot(modem_context_t *ctx, cell_snapshot_t *snapshot);
