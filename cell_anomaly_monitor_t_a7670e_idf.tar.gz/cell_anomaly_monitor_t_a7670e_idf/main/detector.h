#pragma once

#include <stdbool.h>
#include <stdint.h>
#include "config.h"

typedef struct baseline_entry {
    bool used;
    rat_mode_t rat;
    char plmn[MODEM_TEXT_LEN];
    uint32_t tac;
    uint32_t cell_id;
    int seen_count;
    int64_t first_seen_ms;
    int64_t last_seen_ms;
    int avg_rsrp_dbm;
    int avg_rssi_dbm;
} baseline_entry_t;

typedef struct detector_state {
    baseline_entry_t entries[BASELINE_CAPACITY];
    bool has_previous;
    cell_snapshot_t previous;
    int64_t last_reg_change_ms;
    int reg_flap_count;
    int sample_count;
} detector_state_t;

void detector_init(detector_state_t *state);
void detector_update(detector_state_t *state,
                     const cell_snapshot_t *snapshot,
                     detector_result_t *result);
