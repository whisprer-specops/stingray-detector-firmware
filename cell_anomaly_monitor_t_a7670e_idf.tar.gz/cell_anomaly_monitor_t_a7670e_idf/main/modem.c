#include "modem.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <inttypes.h>

#include "board.h"
#include "config.h"
#include "driver/uart.h"
#include "esp_check.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = APP_TAG ".modem";

static void trim_ascii(char *s)
{
    if (s == NULL || *s == '\0') {
        return;
    }

    char *start = s;
    while (*start != '\0' && isspace((unsigned char)*start)) {
        start++;
    }

    char *end = start + strlen(start);
    while (end > start && isspace((unsigned char)*(end - 1))) {
        end--;
    }
    *end = '\0';

    if (start != s) {
        memmove(s, start, (size_t)(end - start) + 1U);
    }
}

static void safe_copy(char *dst, size_t dst_size, const char *src)
{
    if (dst == NULL || dst_size == 0) {
        return;
    }
    if (src == NULL) {
        dst[0] = '\0';
        return;
    }
    snprintf(dst, dst_size, "%s", src);
}

static int split_csv_mut(char *input, char *parts[], int max_parts)
{
    int count = 0;
    bool in_quote = false;
    char *token_start = input;

    for (char *p = input; *p != '\0'; ++p) {
        if (*p == '"') {
            in_quote = !in_quote;
        } else if (*p == ',' && !in_quote) {
            *p = '\0';
            if (count < max_parts) {
                parts[count++] = token_start;
            }
            token_start = p + 1;
        }
    }

    if (count < max_parts && token_start != NULL) {
        parts[count++] = token_start;
    }

    for (int i = 0; i < count; ++i) {
        trim_ascii(parts[i]);
        size_t len = strlen(parts[i]);
        if (len >= 2 && parts[i][0] == '"' && parts[i][len - 1] == '"') {
            parts[i][len - 1] = '\0';
            memmove(parts[i], parts[i] + 1, len - 1);
        }
    }

    return count;
}

static uint32_t parse_u32_auto(const char *text)
{
    if (text == NULL || *text == '\0') {
        return 0;
    }
    return (uint32_t)strtoul(text, NULL, 0);
}

static int parse_int_or_default(const char *text, int fallback)
{
    if (text == NULL || *text == '\0') {
        return fallback;
    }
    char *endptr = NULL;
    long value = strtol(text, &endptr, 0);
    if (endptr == text) {
        return fallback;
    }
    return (int)value;
}

static float rsrq_report_to_db(int raw)
{
    if (raw < 0 || raw == 255) {
        return 0.0f;
    }
    return ((float)raw - 40.0f) / 2.0f;
}

static int rsrp_report_to_dbm(int raw)
{
    if (raw < 0 || raw == 255) {
        return 0;
    }
    return raw - 140;
}

static int rssi_report_to_dbm(int raw)
{
    if (raw < 0 || raw == 255) {
        return 0;
    }
    return raw - 110;
}

static int csq_to_rssi_dbm(int code)
{
    if (code == 99 || code < 0) {
        return 0;
    }
    if (code == 0) {
        return -113;
    }
    if (code == 1) {
        return -111;
    }
    if (code >= 2 && code <= 30) {
        return -109 + ((code - 2) * 2);
    }
    if (code == 31) {
        return -51;
    }
    return 0;
}

static rat_mode_t rat_from_text(const char *text)
{
    if (text == NULL) {
        return RAT_UNKNOWN;
    }
    if (strcasecmp(text, "NO SERVICE") == 0) {
        return RAT_NO_SERVICE;
    }
    if (strcasecmp(text, "GSM") == 0) {
        return RAT_GSM;
    }
    if (strcasecmp(text, "WCDMA") == 0) {
        return RAT_WCDMA;
    }
    if (strcasecmp(text, "LTE") == 0) {
        return RAT_LTE;
    }
    return RAT_UNKNOWN;
}

static bool response_has_terminal(const char *buf)
{
    return strstr(buf, "\r\nOK\r\n") != NULL ||
           strstr(buf, "\nOK\r\n") != NULL ||
           strstr(buf, "\r\nERROR\r\n") != NULL ||
           strstr(buf, "+CME ERROR") != NULL;
}

static esp_err_t modem_send_command(const char *command,
                                    char *out,
                                    size_t out_size,
                                    int timeout_ms)
{
    if (out == NULL || out_size == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    memset(out, 0, out_size);
    ESP_RETURN_ON_ERROR(uart_flush(MODEM_UART_PORT), TAG, "flush before command");
    ESP_RETURN_ON_ERROR(uart_flush_input(MODEM_UART_PORT), TAG, "flush input before command");

    const int written = uart_write_bytes(MODEM_UART_PORT, command, (uint32_t)strlen(command));
    if (written < 0) {
        return ESP_FAIL;
    }
    uart_write_bytes(MODEM_UART_PORT, "\r\n", 2);
    uart_wait_tx_done(MODEM_UART_PORT, pdMS_TO_TICKS(100));

    size_t used = 0;
    const int64_t deadline = esp_timer_get_time() + ((int64_t)timeout_ms * 1000LL);

    while (esp_timer_get_time() < deadline) {
        uint8_t chunk[96];
        const int got = uart_read_bytes(MODEM_UART_PORT, chunk, sizeof(chunk), pdMS_TO_TICKS(150));
        if (got > 0) {
            size_t remaining = (used < out_size) ? (out_size - used - 1U) : 0U;
            size_t copy_len = (remaining < (size_t)got) ? remaining : (size_t)got;
            if (copy_len > 0) {
                memcpy(out + used, chunk, copy_len);
                used += copy_len;
                out[used] = '\0';
            }
            if (response_has_terminal(out)) {
                return (strstr(out, "ERROR") != NULL) ? ESP_FAIL : ESP_OK;
            }
        }
    }

    return ESP_ERR_TIMEOUT;
}

static esp_err_t modem_probe_basic(void)
{
    char resp[MONITOR_MAX_AT_RESPONSE];
    for (int i = 0; i < 10; ++i) {
        const esp_err_t err = modem_send_command("AT", resp, sizeof(resp), 1000);
        if (err == ESP_OK && strstr(resp, "OK") != NULL) {
            return ESP_OK;
        }
        vTaskDelay(pdMS_TO_TICKS(200));
    }
    return ESP_ERR_TIMEOUT;
}

static const char *find_line_after_prefix(const char *response, const char *prefix)
{
    const char *p = strstr(response, prefix);
    if (p == NULL) {
        return NULL;
    }
    p += strlen(prefix);
    while (*p == ' ' || *p == '\t') {
        ++p;
    }
    return p;
}

static void copy_line(const char *start, char *dst, size_t dst_size)
{
    if (dst == NULL || dst_size == 0) {
        return;
    }
    dst[0] = '\0';
    if (start == NULL) {
        return;
    }

    const char *end = strpbrk(start, "\r\n");
    size_t len = (end == NULL) ? strlen(start) : (size_t)(end - start);
    if (len >= dst_size) {
        len = dst_size - 1U;
    }
    memcpy(dst, start, len);
    dst[len] = '\0';
    trim_ascii(dst);
}

static void parse_csq_line(const char *response, cell_snapshot_t *snapshot)
{
    char line[MODEM_RAW_LINE_LEN];
    copy_line(find_line_after_prefix(response, "+CSQ:"), line, sizeof(line));
    if (line[0] == '\0') {
        return;
    }

    char *parts[2] = {0};
    int count = split_csv_mut(line, parts, 2);
    if (count >= 1) {
        snapshot->csq_rssi_code = parse_int_or_default(parts[0], 99);
        if (snapshot->rssi_dbm == 0) {
            snapshot->rssi_dbm = csq_to_rssi_dbm(snapshot->csq_rssi_code);
        }
    }
    if (count >= 2) {
        snapshot->csq_ber = parse_int_or_default(parts[1], 99);
    }
}

static void parse_creg_like(const char *response,
                            const char *prefix,
                            int *mode_out,
                            int *stat_out,
                            uint32_t *lac_out,
                            uint32_t *ci_out)
{
    char line[MODEM_RAW_LINE_LEN];
    copy_line(find_line_after_prefix(response, prefix), line, sizeof(line));
    if (line[0] == '\0') {
        return;
    }

    char *parts[5] = {0};
    int count = split_csv_mut(line, parts, 5);
    if (count >= 1) {
        *mode_out = parse_int_or_default(parts[0], *mode_out);
    }
    if (count >= 2) {
        *stat_out = parse_int_or_default(parts[1], *stat_out);
    }
    if (count >= 3 && lac_out != NULL) {
        *lac_out = parse_u32_auto(parts[2]);
    }
    if (count >= 4 && ci_out != NULL) {
        *ci_out = parse_u32_auto(parts[3]);
    }
}

static void parse_cpin(const char *response, cell_snapshot_t *snapshot)
{
    char line[MODEM_RAW_LINE_LEN];
    copy_line(find_line_after_prefix(response, "+CPIN:"), line, sizeof(line));
    if (line[0] == '\0') {
        return;
    }
    snapshot->sim_ready = (strcasecmp(line, "READY") == 0);
}

static void parse_simcomati(const char *response, modem_context_t *ctx)
{
    char tmp[MONITOR_MAX_AT_RESPONSE];
    safe_copy(tmp, sizeof(tmp), response);

    char *saveptr = NULL;
    char *line = strtok_r(tmp, "\r\n", &saveptr);
    char first_nonempty[MODEM_TEXT_LEN] = {0};
    char second_nonempty[MODEM_TEXT_LEN] = {0};

    while (line != NULL) {
        trim_ascii(line);
        if (line[0] != '\0' && strcasecmp(line, "AT+SIMCOMATI") != 0 && strcasecmp(line, "OK") != 0) {
            if (first_nonempty[0] == '\0') {
                safe_copy(first_nonempty, sizeof(first_nonempty), line);
            } else if (second_nonempty[0] == '\0') {
                safe_copy(second_nonempty, sizeof(second_nonempty), line);
                break;
            }
        }
        line = strtok_r(NULL, "\r\n", &saveptr);
    }

    safe_copy(ctx->model, sizeof(ctx->model), first_nonempty);
    safe_copy(ctx->revision, sizeof(ctx->revision), second_nonempty);
}

static void parse_cpsi_line(const char *response, cell_snapshot_t *snapshot)
{
    char line[MODEM_RAW_LINE_LEN];
    copy_line(find_line_after_prefix(response, "+CPSI:"), line, sizeof(line));
    if (line[0] == '\0') {
        return;
    }

    safe_copy(snapshot->cpsi_line, sizeof(snapshot->cpsi_line), line);

    char working[MODEM_RAW_LINE_LEN];
    safe_copy(working, sizeof(working), line);

    char *parts[16] = {0};
    int count = split_csv_mut(working, parts, 16);
    if (count < 2) {
        return;
    }

    safe_copy(snapshot->rat_text, sizeof(snapshot->rat_text), parts[0]);
    safe_copy(snapshot->op_mode, sizeof(snapshot->op_mode), parts[1]);
    snapshot->rat = rat_from_text(parts[0]);
    snapshot->no_service = (snapshot->rat == RAT_NO_SERVICE);

    if (snapshot->rat == RAT_GSM && count >= 7) {
        safe_copy(snapshot->plmn, sizeof(snapshot->plmn), parts[2]);
        snapshot->tac = parse_u32_auto(parts[3]);
        snapshot->cell_id = parse_u32_auto(parts[4]);
        snapshot->rssi_dbm = csq_to_rssi_dbm(parse_int_or_default(parts[6], snapshot->csq_rssi_code));
        safe_copy(snapshot->band, sizeof(snapshot->band), "GSM");
    } else if (snapshot->rat == RAT_WCDMA && count >= 9) {
        safe_copy(snapshot->plmn, sizeof(snapshot->plmn), parts[2]);
        snapshot->tac = parse_u32_auto(parts[3]);
        snapshot->cell_id = parse_u32_auto(parts[4]);
        safe_copy(snapshot->band, sizeof(snapshot->band), parts[5]);
    } else if (snapshot->rat == RAT_LTE && count >= 13) {
        safe_copy(snapshot->plmn, sizeof(snapshot->plmn), parts[2]);
        snapshot->tac = parse_u32_auto(parts[3]);
        snapshot->cell_id = parse_u32_auto(parts[4]);
        snapshot->pcell_id = parse_int_or_default(parts[5], 0);
        safe_copy(snapshot->band, sizeof(snapshot->band), parts[6]);
        snapshot->earfcn = parse_int_or_default(parts[7], 0);
        snapshot->dlbw = parse_int_or_default(parts[8], 0);
        snapshot->ulbw = parse_int_or_default(parts[9], 0);
        snapshot->rsrq_db = rsrq_report_to_db(parse_int_or_default(parts[10], -1));
        snapshot->rsrp_dbm = rsrp_report_to_dbm(parse_int_or_default(parts[11], -1));
        snapshot->rssi_dbm = rssi_report_to_dbm(parse_int_or_default(parts[12], -1));
        if (count >= 14) {
            snapshot->rssnr_raw = parse_int_or_default(parts[13], 0);
        }
    }
}

static bool registration_state_is_registered(int stat)
{
    return stat == 1 || stat == 5;
}

esp_err_t modem_init(modem_context_t *ctx)
{
    if (ctx == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    memset(ctx, 0, sizeof(*ctx));

    ESP_RETURN_ON_ERROR(board_init_power_domain(), TAG, "power rail init");
    ESP_RETURN_ON_ERROR(board_init_uart(), TAG, "uart init");
    ESP_RETURN_ON_ERROR(board_prepare_modem_pins(), TAG, "modem pins init");

    for (int attempt = 1; attempt <= MODEM_BOOT_RETRIES; ++attempt) {
        ctx->boot_attempts = attempt;
        board_modem_hold_awake();
        board_modem_reset_pulse();
        board_modem_power_key_pulse();
        vTaskDelay(pdMS_TO_TICKS(MODEM_START_WAIT_MS));

        if (modem_probe_basic() == ESP_OK) {
            ctx->ready = true;
            break;
        }
        ESP_LOGW(TAG, "modem did not answer on boot attempt %d", attempt);
    }

    if (!ctx->ready) {
        return ESP_ERR_TIMEOUT;
    }

    char resp[MONITOR_MAX_AT_RESPONSE];
    if (modem_send_command("ATE0", resp, sizeof(resp), MODEM_COMMAND_TIMEOUT_MS) != ESP_OK) {
        ESP_LOGW(TAG, "ATE0 failed; continuing");
    }
    if (modem_send_command("AT+CMEE=2", resp, sizeof(resp), MODEM_COMMAND_TIMEOUT_MS) != ESP_OK) {
        ESP_LOGW(TAG, "CMEE setup failed; continuing");
    }
    if (modem_send_command("AT+SIMCOMATI", resp, sizeof(resp), MODEM_COMMAND_TIMEOUT_MS) == ESP_OK) {
        parse_simcomati(resp, ctx);
        ESP_LOGI(TAG, "modem model: %s | rev: %s", ctx->model, ctx->revision);
    }

    return ESP_OK;
}

esp_err_t modem_collect_snapshot(modem_context_t *ctx, cell_snapshot_t *snapshot)
{
    if (ctx == NULL || snapshot == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    memset(snapshot, 0, sizeof(*snapshot));
    snapshot->valid = false;
    snapshot->csq_rssi_code = 99;
    snapshot->csq_ber = 99;
    snapshot->uptime_ms = esp_timer_get_time() / 1000LL;
    safe_copy(snapshot->modem_model, sizeof(snapshot->modem_model), ctx->model);
    safe_copy(snapshot->modem_revision, sizeof(snapshot->modem_revision), ctx->revision);

    char resp[MONITOR_MAX_AT_RESPONSE];

    if (modem_send_command("AT+CPIN?", resp, sizeof(resp), MODEM_COMMAND_TIMEOUT_MS) == ESP_OK) {
        parse_cpin(resp, snapshot);
    }

    if (modem_send_command("AT+CSQ", resp, sizeof(resp), MODEM_COMMAND_TIMEOUT_MS) == ESP_OK) {
        parse_csq_line(resp, snapshot);
    }

    if (modem_send_command("AT+CREG?", resp, sizeof(resp), MODEM_COMMAND_TIMEOUT_MS) == ESP_OK) {
        parse_creg_like(resp, "+CREG:", &snapshot->creg_mode, &snapshot->creg_stat, NULL, NULL);
    }

    if (modem_send_command("AT+CEREG?", resp, sizeof(resp), MODEM_COMMAND_TIMEOUT_MS) == ESP_OK) {
        parse_creg_like(resp, "+CEREG:", &snapshot->cereg_mode, &snapshot->cereg_stat, &snapshot->tac, &snapshot->cell_id);
    }

    esp_err_t cpsi_err = modem_send_command("AT+CPSI?", resp, sizeof(resp), MODEM_COMMAND_TIMEOUT_MS);
    safe_copy(ctx->last_response, sizeof(ctx->last_response), resp);
    if (cpsi_err == ESP_OK) {
        parse_cpsi_line(resp, snapshot);
    } else {
        ESP_LOGW(TAG, "AT+CPSI? failed: %s", esp_err_to_name(cpsi_err));
    }

    if (snapshot->rat == RAT_UNKNOWN) {
        if (registration_state_is_registered(snapshot->cereg_stat)) {
            snapshot->rat = RAT_LTE;
            safe_copy(snapshot->rat_text, sizeof(snapshot->rat_text), "LTE");
        } else if (registration_state_is_registered(snapshot->creg_stat)) {
            snapshot->rat = RAT_GSM;
            safe_copy(snapshot->rat_text, sizeof(snapshot->rat_text), "GSM");
        }
    }

    snapshot->registered = registration_state_is_registered(snapshot->cereg_stat) ||
                           registration_state_is_registered(snapshot->creg_stat);
    snapshot->no_service = snapshot->no_service || !snapshot->registered;

    snapshot->valid = snapshot->sim_ready;
    return snapshot->valid ? ESP_OK : ESP_FAIL;
}
