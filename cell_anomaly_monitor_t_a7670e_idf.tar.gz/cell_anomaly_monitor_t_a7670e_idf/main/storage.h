#pragma once

#include <stdbool.h>
#include "esp_err.h"
#include "config.h"

typedef struct storage_context {
    bool mounted;
    int log_count;
    int event_count;
} storage_context_t;

esp_err_t storage_init(storage_context_t *ctx);
void storage_deinit(storage_context_t *ctx);
esp_err_t storage_append_snapshot(storage_context_t *ctx,
                                  const cell_snapshot_t *snapshot,
                                  const detector_result_t *result);
