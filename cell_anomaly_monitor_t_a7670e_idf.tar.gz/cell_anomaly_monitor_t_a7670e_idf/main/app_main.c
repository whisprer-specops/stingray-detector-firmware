#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <stdarg.h>

#include "board.h"
#include "detector.h"
#include "esp_err.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "modem.h"
#include "nvs_flash.h"
#include "oled_ssd1306.h"
#include "storage.h"

static const char *TAG = APP_TAG ".app";

static const char *level_text(event_level_t level)
{
    switch (level) {
        case EVENT_LOW: return "LOW";
        case EVENT_MEDIUM: return "MED";
        case EVENT_HIGH: return "HIGH";
        default: return "NONE";
    }
}

static void fit_line(char *dst, size_t dst_size, const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    vsnprintf(dst, dst_size, fmt, args);
    va_end(args);
    if (dst_size > 0) {
        dst[dst_size - 1] = '\0';
    }
}

static void render_display(const display_state_t *state)
{
    char line[OLED_TEXT_COLS + 1];

    oled_clear();

    fit_line(line, sizeof(line), "CELL ANOMALY MON");
    oled_draw_text(0, 0, line);

    fit_line(line, sizeof(line), "%s %s %s",
             state->storage_ready ? "SD" : "NO-SD",
             state->modem_ready ? "MODEM" : "NO-MODEM",
             level_text(state->last_level));
    oled_draw_text(0, 1, line);

    const cell_snapshot_t *s = &state->last_snapshot;
    fit_line(line, sizeof(line), "%s REG:%d SCORE:%d",
             s->rat_text[0] ? s->rat_text : "?",
             s->registered ? 1 : 0,
             state->last_score);
    oled_draw_text(0, 2, line);

    fit_line(line, sizeof(line), "%s", s->plmn[0] ? s->plmn : "PLMN ?");
    oled_draw_text(0, 3, line);

    fit_line(line, sizeof(line), "TAC:%04X CI:%08X", s->tac, s->cell_id);
    oled_draw_text(0, 4, line);

    fit_line(line, sizeof(line), "RSRP:%d RSSI:%d", s->rsrp_dbm, s->rssi_dbm);
    oled_draw_text(0, 5, line);

    fit_line(line, sizeof(line), "LOG:%d EVT:%d", state->sample_count, state->event_count);
    oled_draw_text(0, 6, line);

    fit_line(line, sizeof(line), "%s", state->status_line[0] ? state->status_line : "PASSIVE MONITOR");
    oled_draw_text(0, 7, line);

    oled_present();
}

void app_main(void)
{
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(err);

    display_state_t display = {0};
    modem_context_t modem = {0};
    detector_state_t detector;
    storage_context_t storage = {0};
    oled_context_t oled = {0};

    detector_init(&detector);

    ESP_LOGI(TAG, "booting %s", BOARD_VARIANT_NAME);

    if (board_init_i2c() == ESP_OK && oled_init(&oled) == ESP_OK) {
        display.modem_ready = false;
        display.storage_ready = false;
        fit_line(display.status_line, sizeof(display.status_line), "BOOTING...");
        render_display(&display);
    }

    board_init_power_domain();

    if (storage_init(&storage) == ESP_OK) {
        display.storage_ready = true;
    } else {
        fit_line(display.status_line, sizeof(display.status_line), "SD MOUNT FAILED");
        render_display(&display);
    }

    if (modem_init(&modem) == ESP_OK) {
        display.modem_ready = true;
        fit_line(display.status_line, sizeof(display.status_line), "MODEM READY");
    } else {
        display.modem_ready = false;
        fit_line(display.status_line, sizeof(display.status_line), "MODEM INIT FAIL");
        render_display(&display);
    }

    render_display(&display);
    vTaskDelay(pdMS_TO_TICKS(500));

    for (;;) {
        cell_snapshot_t snapshot = {0};
        detector_result_t result = {0};

        if (display.modem_ready && modem_collect_snapshot(&modem, &snapshot) == ESP_OK) {
            detector_update(&detector, &snapshot, &result);
            display.last_snapshot = snapshot;
            display.last_detector = result;
            display.last_score = result.score;
            display.last_level = result.level;
            display.sample_count += 1;

            if (storage.mounted) {
                err = storage_append_snapshot(&storage, &snapshot, &result);
                result.sd_logging_ok = (err == ESP_OK);
                display.storage_ready = (err == ESP_OK);
                display.event_count = storage.event_count;
            }

            if (result.level >= EVENT_LOW) {
                fit_line(display.status_line, sizeof(display.status_line), "%s", result.flags[0] ? result.flags : "ANOMALY");
            } else {
                fit_line(display.status_line, sizeof(display.status_line), "BASELINE:%d BAND:%s", result.baseline_hits, snapshot.band);
            }

            ESP_LOGI(TAG,
                     "t=%" PRId64 "ms rat=%s reg=%d plmn=%s tac=%u ci=%u rsrp=%d rssi=%d score=%d flags=%s",
                     snapshot.uptime_ms,
                     snapshot.rat_text,
                     snapshot.registered,
                     snapshot.plmn,
                     snapshot.tac,
                     snapshot.cell_id,
                     snapshot.rsrp_dbm,
                     snapshot.rssi_dbm,
                     result.score,
                     result.flags);
        } else {
            fit_line(display.status_line, sizeof(display.status_line), "QUERY FAILED");
            display.last_level = EVENT_NONE;
            display.last_score = 0;
        }

        render_display(&display);
        vTaskDelay(pdMS_TO_TICKS(MONITOR_POLL_INTERVAL_MS));
    }
}
