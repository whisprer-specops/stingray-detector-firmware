# Cell Anomaly Monitor for LilyGo T-A7670E / T-A7670G (ESP-IDF)

This is a **passive** ESP-IDF project for the LilyGo T-A7670X ESP32 boards.
It powers the modem and SD rail correctly, queries the modem over UART with AT commands,
logs radio/network state to microSD, computes a simple anomaly score from changes over time,
and renders status to an SSD1306 OLED.

It is **not** an active network tool, and it does **not** interfere with cellular service.
It only queries the local modem for information such as registration state, serving-cell data,
and signal metrics.

## What it does

- powers the LilyGo peripheral rail on GPIO12
- initializes the A7670 modem on UART1
- uses passive AT queries:
  - `AT`
  - `ATE0`
  - `AT+CMEE=2`
  - `AT+SIMCOMATI`
  - `AT+CPIN?`
  - `AT+CSQ`
  - `AT+CREG?`
  - `AT+CEREG?`
  - `AT+CPSI?`
- stores a rolling in-memory baseline of observed cells
- assigns a heuristic anomaly score for:
  - fast cell churn
  - registration flapping
  - LTE -> GSM downgrade
  - strong previously unseen cell
  - abrupt signal jumps
  - PLMN changes
- logs every sample to CSV on microSD
- logs alert-level events to JSONL on microSD
- shows current state and score on a 128x64 SSD1306 OLED

## Assumptions

- board: **LilyGo T-A7670E or T-A7670G ESP32 version**
- framework: **ESP-IDF**
- display: **SSD1306 128x64 I2C OLED at 0x3C**
- storage: onboard **microSD over SDSPI**
- default OLED pins: **GPIO21 SDA / GPIO22 SCL**

If your board is the **A7670G external-GPS** variant, GPIO21/22 may already be occupied by GNSS.
In that case, override `BOARD_GPIO_OLED_SDA` / `BOARD_GPIO_OLED_SCL` in `main/config.h` before building.

## Pin mapping used here

These values match LilyGo's published quick-start mapping for the T-A7670X ESP32 line:

- peripheral power control: GPIO12
- modem TX: GPIO26
- modem RX: GPIO27
- modem PWRKEY: GPIO4
- modem RESET: GPIO5
- modem DTR: GPIO25
- modem RING: GPIO33
- SD SCK: GPIO14
- SD MISO: GPIO2
- SD MOSI: GPIO15
- SD CS: GPIO13
- default I2C SDA/SCL: GPIO21 / GPIO22

## Build

```bash
idf.py set-target esp32
idf.py build
idf.py -p <PORT> flash monitor
```

## Logs

When SD mount succeeds, logs are written to:

- `/sdcard/cellmon/cell_log.csv`
- `/sdcard/cellmon/anomaly_events.jsonl`

## Notes

- This is intentionally a **transparent heuristic monitor**, not a “magic detector.”
- The anomaly score is only a triage signal and will need local tuning.
- Network optimization and carrier behavior can produce false positives.
- Power quality matters: if the board is unstable, fix power first.
- The code keeps interaction passive and avoids attach/profile manipulation beyond normal read-only status queries.

## Project layout

- `main/app_main.c` — app loop, OLED rendering, orchestration
- `main/board.*` — board rail, UART, I2C, modem pin sequencing
- `main/modem.*` — AT transport and parsers
- `main/detector.*` — baseline + anomaly scoring
- `main/storage.*` — microSD mount + CSV/JSONL logging
- `main/oled_ssd1306.*` — minimal self-contained SSD1306 driver
- `main/oled_font_6x8.h` — embedded 6x8 bitmap font

## Tuning points

Open `main/config.h` and adjust:

- poll interval
- OLED pins and address
- score thresholds
- strong-signal thresholds
- churn / flap windows

## Source basis used while building this

- the uploaded article for the overall **passive anomaly-detection** concept and logging/baseline approach
- LilyGo T-A7670X ESP32 quick-start docs for pin mapping and power-rail behavior
- SIMCom A76XX AT command manual for `AT+CSQ`, `AT+CREG?`, `AT+CEREG?`, and `AT+CPSI?`
